# probe_utils
Package for RAP probe generation

This package contains tools for generating and ordering probes for RNA Antisense Purification (RAP). The following links will take you to demos for the tools in this package.

[rap_probes()](https://honsonbiosci.github.io/softwarepackages/rapprobesdemo.html)
